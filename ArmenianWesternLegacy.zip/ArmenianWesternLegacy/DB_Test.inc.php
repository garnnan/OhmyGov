<?php

require_once ('DB_mysql.inc.php');

class DB_Test {

    static function obtenEstados() {
        $db = new DB_mysql;
        $db->openConnection();
        $db->executeQuery("SELECT nombre FROM `estados`;");
        $rs = $db->getResultSet();
        $db->closeConnection();
        return $rs;
    }

    static function obtenMunicipios($estado) {
        $db = new DB_mysql;
        $db->openConnection();
        $db->executeQuery("SELECT nombre FROM `municipios` WHERE estado = '$estado';");
        $rs = $db->getResultSet();
        $db->closeConnection();
        return $rs;
    }

    static function obtenDistritos($municipio) {
        $db = new DB_mysql;
        $db->openConnection();
        $db->executeQuery("SELECT nombre FROM `distritos` WHERE estado LIKE '$municipio';");
        $rs = $db->getResultSet();
        $db->closeConnection();
        return $rs;
    }
    
    static function obtenEstadosId($nombre) {
        $db = new DB_mysql;
        $db->openConnection();
        $db->executeQuery("SELECT id FROM `estados` WHERE nombre LIKE '$nombre';");
        $rs = $db->getResultSet();
        $db->closeConnection();
        return $rs;
    }
    
    static function obtenMunicipiosId($nombre) {
        $db = new DB_mysql;
        $db->openConnection();
        $db->executeQuery("SELECT id FROM `municipios` WHERE nombre LIKE '$nombre';");
        $rs = $db->getResultSet();
        $db->closeConnection();
        return $rs;
    }
    
    static function obtenDistritosId($nombre) {
        $db = new DB_mysql;
        $db->openConnection();
        $db->executeQuery("SELECT id FROM `distritos`WHERE nombre LIKE '$nombre';");
        $rs = $db->getResultSet();
        $db->closeConnection();
        return $rs;
    }
//presidente
    static function Pregunta1() {
        $db = new DB_mysql;
        $db->openConnection();
        $db->executeQuery("Select candidato.nombre as Nombre, candidato.apellidoP as ApellidoPaterno, candidato.apellidoM as ApellidoMaterno , candidato.foto, candidato.pagina
From candidato, candidatura, periodo
Where candidatura.id_cargo='1' 
and candidatura.vigencia=1 
and candidato.id=candidatura.id_candidato 
and candidatura.id_periodo=periodo.id;");
        $rs = $db->getResultSet();
        $db->closeConnection();
        return $rs;
    }
//presidente anterior
    static function Pregunta2() {
        $db = new DB_mysql;
        $db->openConnection();
        $db->executeQuery("Select candidato.nombre as Nombre, candidato.apellidoP as ApellidoPaterno, candidato.apellidoM as ApellidoMaterno 
From candidato, candidatura, periodo
Where candidatura.id_cargo='1' 
and candidatura.vigencia=0 
and candidato.id=candidatura.id_candidato 
and candidatura.id_periodo=periodo.id 
AND periodo.FIN=2012;");
        $rs = $db->getResultSet();
        $db->closeConnection();
        return $rs;
    }
//gober
    static function Pregunta3() {
        $db = new DB_mysql;
        $db->openConnection();
        $db->executeQuery("Select candidato.nombre as Nombre, candidato.apellidoP as ApellidoPaterno, candidato.apellidoM as ApellidoMaterno 
From candidato, candidatura, periodo
Where candidatura.id_cargo='2' 
and candidatura.vigencia=1 
and candidato.id=candidatura.id_candidato 
and candidatura.id_periodo=periodo.id;");
        $rs = $db->getResultSet();
        $db->closeConnection();
        return $rs;
    }
//partido gober
    static function Pregunta4() {
        $db = new DB_mysql;
        $db->openConnection();
        $db->executeQuery("Select candidato.nombre as Nombre, candidato.apellidoP as ApellidoPaterno, candidato.apellidoM as ApellidoMaterno, partido.nombre as Partido
From candidato, candidatura, partido
Where candidatura.id_cargo='2' and candidatura.vigencia=1 and candidato.id=candidatura.id_candidato and partido.id=candidatura.id_partido;");
        $rs = $db->getResultSet();
        $db->closeConnection();
        return $rs;
    }
//candidatos presidencia
    static function Pregunta5() {        
        $db = new DB_mysql;
        $db->openConnection();
        $db->executeQuery("Select candidato.nombre as Nombre, candidato.apellidoP as ApellidoPaterno, candidato.apellidoM as ApellidoMaterno, partido.nombre as Partido, candidato.foto, candidato.pagina
From candidato, candidatura, partido, periodo
Where candidatura.id_cargo='1' 
and candidatura.elegido=0 
and candidatura.vigencia=0
and periodo.inicio =2018
and candidato.id=candidatura.id_candidato 
and partido.id=candidatura.id_partido
and candidatura.id_periodo=periodo.id;");
        $rs = $db->getResultSet();
        $db->closeConnection();
        return $rs;
    }
//diputado
    static function Pregunta6() {
       
        $db = new DB_mysql;
        $db->openConnection();
        $db->executeQuery("Select candidato.nombre as Nombre, candidato.apellidoP as ApellidoPaterno, candidato.apellidoM as ApellidoMaterno 
From candidato, candidatura, periodo
Where candidatura.id_cargo='3' 
and candidatura.vigencia=1 
and candidato.id=candidatura.id_candidato 
and candidatura.id_periodo=periodo.id;");
        $rs = $db->getResultSet();
        $db->closeConnection();
        return $rs;
    }
//distrito
    static function Pregunta7($estado, $municipio, $seccion) {
        $db = new DB_mysql;
        $db->openConnection();
        $db->executeQuery("SELECT distrito FROM `distritos` WHERE estado='$estado' AND municipio='$municipio' AND '$seccion'>=inicio AND '$seccion'<=fin  ;");
        $rs = $db->getResultSet();
        $db->closeConnection();
        return $rs;
    }
//Gober Precioso
    static function Pregunta8($estado) {
        $db = new DB_mysql;
        $db->openConnection();
        $db->executeQuery("Select candidato.nombre as Nombre, candidato.apellidoP as ApellidoPaterno, candidato.apellidoM as ApellidoMaterno 
From candidato, candidatura, periodo, estados, distritos
Where candidatura.id_cargo='2' 
and candidatura.vigencia=1
and estados.id='$estado'
and candidato.id=candidatura.id_candidato 
and candidatura.id_periodo=periodo.id
and candidatura.id_distrito=distritos.id;");
        $rs = $db->getResultSet();
        $db->closeConnection();
        return $rs;
    }
//Presidente municipal
    static function Pregunta9($municipio) {
        $db = new DB_mysql;
        $db->openConnection();
        $db->executeQuery("Select candidato.nombre as Nombre, candidato.apellidoP as ApellidoPaterno, candidato.apellidoM as ApellidoMaterno, candidato.foto, candidato.pagina
From candidato, candidatura, periodo, estados, distritos, municipios
Where candidatura.id_cargo='3' 
and candidatura.vigencia=1
and municipios.id='$municipio'
and candidato.id=candidatura.id_candidato 
and candidatura.id_periodo=periodo.id
and candidatura.id_distrito=distritos.id;");
        $rs = $db->getResultSet();
        $db->closeConnection();
        return $rs;
    }
//diputado info 
    static function Pregunta10($distrito) {
        $db = new DB_mysql;
        $db->openConnection();
        $db->executeQuery("Select candidato.nombre as Nombre, candidato.apellidoP as ApellidoPaterno, candidato.apellidoM as ApellidoMaterno, candidato.foto, candidato.pagina
From candidato, candidatura, periodo, estados, distritos, municipios
Where candidatura.id_cargo='3' 
and candidatura.vigencia=1
and distritos.id='$distrito'
and candidato.id=candidatura.id_candidato 
and candidatura.id_periodo=periodo.id
and candidatura.id_distrito=distritos.id;");
        $rs = $db->getResultSet();
        $db->closeConnection();
        return $rs;
    }
//candidatos gobernatura
    static function Pregunta11($estado) {        
        $db = new DB_mysql;
        $db->openConnection();
        $db->executeQuery("Select candidato.nombre as Nombre, candidato.apellidoP as ApellidoPaterno, candidato.apellidoM as ApellidoMaterno, partido.nombre as Partido, candidato.foto, candidato.pagina
From candidato, candidatura, partido, periodo, estados
Where candidatura.id_cargo='2' 
and candidatura.elegido=0 
and candidatura.vigencia=0
and periodo.inicio =2016
and estados.id='$estado'
and candidato.id=candidatura.id_candidato 
and partido.id=candidatura.id_partido
and candidatura.id_periodo=periodo.id;");
        $rs = $db->getResultSet();
        $db->closeConnection();
        return $rs;
    }
//candidatos presidencia municipal
    static function Pregunta12() {        
        $db = new DB_mysql;
        $db->openConnection();
        $db->executeQuery("Select candidato.nombre as Nombre, candidato.apellidoP as ApellidoPaterno, candidato.apellidoM as ApellidoMaterno, partido.nombre as Partido, candidato.foto, candidato.pagina
From candidato, candidatura, partido, periodo, municipios
Where candidatura.id_cargo='3' 
and candidatura.elegido=0 
and candidatura.vigencia=0
and periodo.inicio =2016
and municipios.id=116
and candidato.id=candidatura.id_candidato 
and partido.id=candidatura.id_partido
and candidatura.id_periodo=periodo.id;");
        $rs = $db->getResultSet();
        $db->closeConnection();
        return $rs;
    }
 //candidatos a diputados
    static function Pregunta13($distrito) {        
        $db = new DB_mysql;
        $db->openConnection();
        $db->executeQuery("Select candidato.nombre as Nombre, candidato.apellidoP as ApellidoPaterno, candidato.apellidoM as ApellidoMaterno, partido.nombre as Partido, candidato.foto, candidato.pagina
From candidato, candidatura, partido, periodo, distritos
Where candidatura.id_cargo='4' 
and candidatura.elegido=0 
and candidatura.vigencia=0
and periodo.inicio =2016
and distritos.distrito='$distrito'
and candidato.id=candidatura.id_candidato 
and partido.id=candidatura.id_partido
and candidatura.id_periodo=periodo.id;");
        $rs = $db->getResultSet();
        $db->closeConnection();
        return $rs;
    }
    
    static function Aleatorio($id) {
       
        $aleatorio= rand(1, 39);
        
        while ($aleatorio==$id){
            $aleatorio= rand(1, 39);
        }
        
        $db = new DB_mysql;
        $db->openConnection();
        $db->executeQuery("Select candidato.nombre as Nombre, candidato.apellidoP as ApellidoPaterno, candidato.apellidoM as ApellidoMaterno
From candidato
Where candidato.id='$aleatorio';");
        $rs = $db->getResultSet();
        $db->closeConnection();
        return $rs;
    }    
    
    //id candidato
    
    static function candidatoId($nombre, $ap1) {
       
        $db = new DB_mysql;
        $db->openConnection();
        $db->executeQuery("Select candidato.id as Id
From candidato
Where candidato.nombre like '$nombre' and candidato.apellidoP like '$ap1';");
        $rs = $db->getResultSet();
        $db->closeConnection();
        return $rs;
    } 
    
    

}

?>