<?php

    include('DB_Test.inc.php');
    $estados = DB_Test::obtenEstados();
    

       foreach ($estados as $u) 
         echo ("$u[0];");
        ?>              
 

