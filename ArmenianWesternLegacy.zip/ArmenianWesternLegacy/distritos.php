<?php

    $municipios = $_POST['municipio'];
    require_once ('DB_Test.inc.php');
    $distritos = DB_Test::obtenDistritos($municipios);
    
 foreach ($distritos as $u) 
         echo ("$u[0];");
        ?>              


