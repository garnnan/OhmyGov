<?php
    error_reporting(0);
    
    require_once ('DB_Test.inc.php');    

    
    $estadoNombre = $_POST['estado'];
$municipioNombre = $_POST['municipio'];
$distritoNombre = $_POST['distrito'];

$estado = DB_Test::obtenEstadosId($estadoNombre);
$municipio = DB_Test::obtenMunicipiosId($municipioNombre);
$distrito = DB_Test::obtenDistritosId($distritoNombre);
    
    $presidente = DB_Test::Pregunta1();
    $candidatosPresidente=DB_Test::Pregunta5();
    $gobernador= DB_Test::Pregunta8(21);
    $candidatosGobernador= DB_Test::Pregunta11(21);
    $presidenteMunicipal=  DB_Test::Pregunta9(116);
    $candidatosPresidenteMunicipal= DB_Test::Pregunta12(116);
    $diputado= DB_Test::Pregunta10(1);
    $candidatosDiputado= DB_Test::Pregunta13(1);
        
    foreach ($presidente as $u) 
         echo ("$u[0] $u[1] $u[2], $u[3], $u[4]");
    foreach ($candidatosPresidente as $u) 
         echo (", $u[0] $u[1] $u[2], $u[4], $u[5]");
    echo (";");
    
    foreach ($gobernador as $u) 
         echo ("$u[0] $u[1] $u[2], $u[3], $u[4]");
    foreach ($candidatosGobernador as $u) 
         echo (", $u[0] $u[1] $u[2], $u[4], $u[5]");
    echo (";");
    
    foreach ($presidenteMunicipal as $u) 
         echo ("$u[0] $u[1] $u[2], $u[3], $u[4]");
    foreach ($candidatosPresidenteMunicipal as $u) 
         echo (", $u[0] $u[1] $u[2], $u[4], $u[5]");
    echo (";");
    
    foreach ($diputado as $u) 
         echo ("$u[0] $u[1] $u[2], $u[3], $u[4]");
    foreach ($candidatosDiputado as $u) 
         echo (", $u[0] $u[1] $u[2], $u[4], $u[5]");

    
    
        ?>              
 
