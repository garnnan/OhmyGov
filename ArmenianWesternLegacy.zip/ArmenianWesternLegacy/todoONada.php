<?php

include('DB_Test.inc.php');

$estadoNombre = $_POST['estado'];
$municipioNombre = $_POST['municipio'];
$distritoNombre = $_POST['distrito'];

$estado = DB_Test::obtenEstadosId($estadoNombre);
$municipio = DB_Test::obtenMunicipiosId($municipioNombre);
$distrito = DB_Test::obtenDistritosId($distritoNombre);

$pregunta1 = (int) $_POST['pregunta1'];
$pregunta2 = (int) $_POST['pregunta2'];
$pregunta3 = (int) $_POST['pregunta3'];
$pregunta4 = (int) $_POST['pregunta4'];
$pregunta5 = (int) $_POST['pregunta5'];

$res1;
$res2;
$res3;
$res4;
$res5;

switch ($pregunta1) {
    case 1:
        $res = DB_Test::Pregunta1();
        foreach ($res as $u) {
            echo ("$u[0] $u[1] $u[2]");
            break;
        }
         $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }
        echo (";");
        break;
    case 2:
        $res = DB_Test::Pregunta2();
        foreach ($res as $u) {
            echo ("$u[0] $u[1] $u[2]");
            break;
        }
      $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }
        echo (";");
        break;
    case 3:
        $res = DB_Test::Pregunta3();
        foreach ($res as $u) {
            echo ("$u[0] $u[1] $u[2]");
            break;
        }
         $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }
        echo (";");
        break;
    case 4:
        $res = DB_Test::Pregunta4();
        foreach ($res as $u) {
            echo ("$u[0] $u[1] $u[2]");
            break;
        }
        $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }
        echo (";");
        break;
    case 5:
        $res = DB_Test::Pregunta5();
        foreach ($res as $u) {
            echo ("$u[0] $u[1] $u[2]");
            break;
        }
         $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }
        echo (";");
        break;
    case 6:
        $res = DB_Test::Pregunta6();
        foreach ($res as $u) {
            echo ("$u[0] $u[1] $u[2]");
            break;
        }
        $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }
        echo (";");
        break;
    case 7:
        $res = DB_Test::Pregunta11($estado);
        foreach ($res as $u) {
            echo ("$u[0] $u[1] $u[2]");
            break;
        }
         $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }
        echo (";");
        break;
    case 8:
        $res = DB_Test::Pregunta8($estado);
        foreach ($res as $u) {
            echo ("$u[0] $u[1] $u[2]");
            break;
        }
         $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }
        echo (";");
        break;
    case 9:
        $res = DB_Test::Pregunta9($municipio);
        foreach ($res as $u) {
            echo ("$u[0] $u[1] $u[2]");
            break;
        }
         $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }
        echo (";");
        break;
    case 10:
        $res = DB_Test::Pregunta10($distrito);
        foreach ($res as $u) {
            echo ("$u[0] $u[1] $u[2]");
            break;
        }
         $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }
        echo (";");
        break;
}

switch ($pregunta2) {
    case 1:
        $res2 = DB_Test::Pregunta1();
        foreach ($res2 as $u) {
            echo ("$u[0] $u[1] $u[2]");
            break;
        }
       $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }
        echo (";");
        break;
    case 2:
        $res2 = DB_Test::Pregunta2();
        foreach ($res2 as $u) {
            echo ("$u[0] $u[1] $u[2]");
            break;
        }
        $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }
        echo (";");
        break;
    case 3:
        $res2 = DB_Test::Pregunta3();
        foreach ($res2 as $u) {
            echo ("$u[0] $u[1] $u[2]");
            break;
        }
        $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }
        echo (";");
        break;
    case 4:
        $res2 = DB_Test::Pregunta4();
        foreach ($res2 as $u) {
            echo ("$u[0] $u[1] $u[2]");
            break;
        }
        $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }
        echo (";");
        break;
    case 5:
        $res2 = DB_Test::Pregunta5();
        foreach ($res2 as $u) {
            echo ("$u[0] $u[1] $u[2]");
            break;
        }
         $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }
        echo (";");
        break;
    case 6:
        $res2 = DB_Test::Pregunta6();
        foreach ($res2 as $u) {
            echo ("$u[0] $u[1] $u[2]");
            break;
        }
        $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }
        echo (";");
        break;
    case 7:
        $res2 = DB_Test::Pregunta11($estado);
        foreach ($res2 as $u) {
            echo ("$u[0] $u[1] $u[2]");
            break;
        }
         $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }
        echo (";");
        break;
    case 8:
        $res2 = DB_Test::Pregunta8($estado);
        foreach ($res2 as $u) {
            echo ("$u[0] $u[1] $u[2]");
            break;
        }
        $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }
        echo (";");
        break;
    case 9:
        $res2 = DB_Test::Pregunta9($municipio);
        foreach ($res2 as $u) {
            echo ("$u[0] $u[1] $u[2]");
            break;
        }
         $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }
        echo (";");
        break;
    case 10:
        $res2 = DB_Test::Pregunta10($distrito);
        foreach ($res2 as $u) {
            echo ("$u[0] $u[1] $u[2]");
            break;
        }
         $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }
        echo (";");
        break;
}
switch ($pregunta3) {
    case 1:
        $res3 = DB_Test::Pregunta1();
        foreach ($res3 as $u) {
            echo ("$u[0] $u[1] $u[2]");

            break;
        }
        $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }
        echo (";");
        break;
    case 2:
        $res3 = DB_Test::Pregunta2();
        foreach ($res3 as $u) {
            echo ("$u[0] $u[1] $u[2]");
            break;
        }
         $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }
        echo (";");
        break;
    case 3:
        $res3 = DB_Test::Pregunta3();
        foreach ($res3 as $u) {
            echo ("$u[0] $u[1] $u[2]");

            break;
        }
        $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }
        echo (";");
        break;
    case 4:
        $res3 = DB_Test::Pregunta4();
        foreach ($res3 as $u) {
            echo ("$u[0] $u[1] $u[2]");
            break;
        }
         $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }
        echo (";");
        break;
    case 5:
        $res3 = DB_Test::Pregunta5();
        foreach ($res3 as $u) {
            echo ("$u[0] $u[1] $u[2]");
            break;
        }
        $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }
        echo (";");
        break;
    case 6:
        $res3 = DB_Test::Pregunta6();
        foreach ($res3 as $u) {
            echo ("$u[0] $u[1] $u[2]");
            break;
        }
        $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }
        echo (";");
        break;
    case 7:
        $res3 = DB_Test::Pregunta11($estado);
        foreach ($res3 as $u) {
            echo ("$u[0] $u[1] $u[2]");
            break;
        }
         $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }
        echo (";");
        break;
    case 8:
        $res3 = DB_Test::Pregunta8($estado);
        foreach ($res3 as $u) {
            echo ("$u[0] $u[1] $u[2]");
            break;
        }
        $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }
        echo (";");
        break;
    case 9:
        $res3 = DB_Test::Pregunta9($municipio);
        foreach ($res3 as $u) {
            echo ("$u[0] $u[1] $u[2]");
            break;
        }
       $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }
        echo (";");
        break;
    case 10:
        $res3 = DB_Test::Pregunta10($distrito);
        foreach ($res3 as $u) {
            echo ("$u[0] $u[1] $u[2]");
            break;
        }
         $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }
        echo (";");
        break;
}

switch ($pregunta4) {
    case 1:
        $res4 = DB_Test::Pregunta1();
        foreach ($res4 as $u) {
            echo ("$u[0] $u[1] $u[2]");
            break;
        }
       $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }
        echo (";");
        break;
    case 2:
        $res4 = DB_Test::Pregunta2();
        foreach ($res4 as $u) {
            echo ("$u[0] $u[1] $u[2]");
            break;
        }
        $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }
        echo (";");
        break;
    case 3:
        $res4 = DB_Test::Pregunta3();
        foreach ($res4 as $u) {
            echo ("$u[0] $u[1] $u[2]");
            break;
        }
        $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }
        echo (";");
        break;
    case 4:
        $res4 = DB_Test::Pregunta4();
        foreach ($res4 as $u) {
            echo ("$u[0] $u[1] $u[2]");
            break;
        }
        $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }
        echo (";");
        break;
    case 5:
        $res4 = DB_Test::Pregunta5();
        foreach ($res4 as $u) {
            echo ("$u[0] $u[1] $u[2]");
            break;
        }
        $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }
        echo (";");
        break;
    case 6:
        $res4 = DB_Test::Pregunta6();
        foreach ($res4 as $u) {
            echo ("$u[0] $u[1] $u[2]");
            break;
        }
        $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }
        echo (";");
        break;
    case 7:
        $res4 = DB_Test::Pregunta11($estado);
        foreach ($res4 as $u) {
            echo ("$u[0] $u[1] $u[2]");

            break;
        }

        $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }
        echo (";");
        break;
    case 8:
        $res4 = DB_Test::Pregunta8($estado);
        foreach ($res4 as $u) {
            echo ("$u[0] $u[1] $u[2]");
            break;
        }
         $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }
        echo (";");
        break;
    case 9:
        $res4 = DB_Test::Pregunta9($municipio);
        foreach ($res4 as $u) {
            echo ("$u[0] $u[1] $u[2]");
            break;
        }
         $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }
        echo (";");
        break;
    case 10:
        $res4 = DB_Test::Pregunta10($distrito);
        foreach ($res4 as $u) {
            echo ("$u[0] $u[1] $u[2]");
            break;
        }
        $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }
        echo (";");
        break;
}

switch ($pregunta5) {
    case 1:
        $res5 = DB_Test::Pregunta1();
        foreach ($res5 as $u){
            echo ("$u[0] $u[1] $u[2]");
         break;   
        }
        $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }

        break;
    case 2:
        $res5 = DB_Test::Pregunta2();
        foreach ($res5 as $u){
            echo ("$u[0] $u[1] $u[2]");
         break;   
        }
        $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }

        break;
    case 3:
        $res5 = DB_Test::Pregunta3();
        foreach ($res5 as $u){
            echo ("$u[0] $u[1] $u[2]");
         break;   
        }
        $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }

        break;
    case 4:
        $res5 = DB_Test::Pregunta4();
        foreach ($res5 as $u){
            echo ("$u[0] $u[1] $u[2]");
         break;   
        }
       $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }

        break;
    case 5:
        $res5 = DB_Test::Pregunta5();
        foreach ($res5 as $u) {
            echo ("$u[0] $u[1] $u[2]");
            break;
        }
        $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }

        break;
    case 6:
        $res5 = DB_Test::Pregunta6();
        foreach ($res5 as $u){
            echo ("$u[0] $u[1] $u[2]");
         break;   
        }
         $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }

        break;
    case 7:
        $res5 = DB_Test::Pregunta11($estado);
        foreach ($res5 as $u){
            echo ("$u[0] $u[1] $u[2]");
         break;   
        }
        $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }

        break;
    case 8:
        $res5 = DB_Test::Pregunta8($estado);
        foreach ($res5 as $u){
            echo ("$u[0] $u[1] $u[2]");
         break;   
        }
        $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }

        break;
    case 9:
        $res5 = DB_Test::Pregunta9($municipio);
        foreach ($res5 as $u){
            echo ("$u[0] $u[1] $u[2]");
            break;
        }
        $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }

        break;
    case 10:
        
        $res5 = DB_Test::Pregunta10($distrito);
        foreach ($res5 as $u){
            
        echo ("$u[0] $u[1] $u[2]");
        break;
        }
        
        $id=DB_Test::candidatoId($u[0],$u[1]);
        
        for ($i = 1; $i <= 3; $i++) {
            $otros = DB_Test::Aleatorio($id);
            foreach ($otros as $u)
                echo (", $u[0] $u[1] $u[2]");
        }

        break;
}
?>              

