<?php

    $estado = $_POST['estado'];
 
    require_once ('DB_Test.inc.php');
    $municipios = DB_Test::obtenMunicipios((int)$estado);
 foreach ($municipios as $u) 
         echo ("$u[0];");
        ?>              
 
