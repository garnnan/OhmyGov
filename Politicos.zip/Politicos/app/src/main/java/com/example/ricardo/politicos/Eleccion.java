package com.example.ricardo.politicos;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

public class Eleccion extends AppCompatActivity {

    private final static ArrayList<Pregunta> PREGUNTAS = new ArrayList<>();
    private static ArrayList<Pregunta> PREGUNTAS_SELECCIONADAS;

    private static String est,mun,dis;

    private Bitmap liga(String src)
    {
        try {

            URL url = new URL(src);

            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setDoInput(true);
            conn.connect();

            InputStream inputStream = conn.getInputStream();
            Bitmap bitmap = BitmapFactory.decodeStream(inputStream);
            return bitmap;

        }catch (Exception e){
            return null;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eleccion);

        PREGUNTAS_SELECCIONADAS = new ArrayList<>();

        PREGUNTAS.add(new Pregunta("¿Quien es tu presidente?"));
        PREGUNTAS.add(new Pregunta("¿Quien fue tu presidente anterior?"));
        PREGUNTAS.add(new Pregunta("¿Quien es tu gobernador?"));
        PREGUNTAS.add(new Pregunta("¿Quien de estos es el candidato de tu estado?"));
        PREGUNTAS.add(new Pregunta("¿Quien es el diputado representante de tu distrito?"));
        PREGUNTAS.add(new Pregunta("¿A que partido pertenece tu gobernador?"));
        PREGUNTAS.add(new Pregunta("¿Quien es el candidato de partido o alianza para presidente?"));
        PREGUNTAS.add(new Pregunta("¿Cuantos municipost tiene tu estado?"));

        new preguntar().execute("http://armenianwesterproject.hol.es/todoONada.php",
                PREGUNTAS.get(0).getPregunta(),
                PREGUNTAS.get(1).getPregunta(),
                PREGUNTAS.get(2).getPregunta(),
                PREGUNTAS.get(3).getPregunta(),
                PREGUNTAS.get(4).getPregunta(),
                PREGUNTAS.get(5).getPregunta(),
                PREGUNTAS.get(6).getPregunta(),
                PREGUNTAS.get(7).getPregunta()
        );

        est = getIntent().getStringExtra("estado");
        mun = getIntent().getStringExtra("municipio");
        dis = getIntent().getStringExtra("distrito");

        Bitmap bitmap = liga("http://asiasociety.org/files/systems-thinking.png");
        Bitmap bitmap1 = liga("http://moment-of-peace.com/images/books.png");

        ((ImageButton) findViewById(R.id.QuizButton)).setImageBitmap(bitmap);
        ((ImageButton) findViewById(R.id.ConsultaButton)).setImageBitmap(bitmap1);

        ((ImageButton) findViewById(R.id.QuizButton)).setEnabled(false);
        ((ImageButton) findViewById(R.id.ConsultaButton)).setEnabled(false);
    }

    //http://armenianwesterproject.hol.es/todoONada.php

    public void quizz (View v)
    {
        Intent i = new Intent(this,Quiz.class);
        i.putExtra("correccion","");
        i.putExtra("pregunta1", PREGUNTAS.get(0).toString());
        i.putExtra("pregunta2",PREGUNTAS.get(1).toString());
        i.putExtra("pregunta3",PREGUNTAS.get(2).toString());
        i.putExtra("pregunta4",PREGUNTAS.get(3).toString());
        i.putExtra("pregunta5",PREGUNTAS.get(4).toString());
        startActivity(i);
    }

    public void  consulta (View v)
    {

        System.out.println(est);
        System.out.println(mun);
        System.out.println(dis);

        Intent i = new Intent(this,Consulta.class);
        i.putExtra("estado",est);
        i.putExtra("municipio",mun);
        i.putExtra("distrito","1");
        startActivity(i);
    }

    private class preguntar extends AsyncTask<String,Void,String>
    {

        @Override
        protected String doInBackground(String... params) {
            String result = "";
            try {

                URL url = new URL(params[0]);

                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(15000);
                conn.setConnectTimeout(15000);
                conn.setRequestMethod("POST");
                conn.setDoInput(true);
                conn.setDoOutput(true);

                HashMap<String,String> postDataParams = new HashMap<>();

                postDataParams.put("municipio",getIntent().getStringExtra("municipio"));
                postDataParams.put("estado",getIntent().getStringExtra("estado"));
                postDataParams.put("distrito",getIntent().getStringExtra("distrito"));

                for (int i=1;i<6;i++) {
                    System.out.println("pregunta" + (i));
                    postDataParams.put("pregunta" + (i), Integer.toString((i)));
                }


                OutputStream os = conn.getOutputStream();

                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os,"UTF-8"));

                writer.write(getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = conn.getResponseCode();

                if(responseCode == HttpURLConnection.HTTP_OK)
                {
                    String line;
                    BufferedReader br = new BufferedReader
                            (new InputStreamReader(conn.getInputStream()));
                    while ((line=br.readLine())!=null)
                        result += line;
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
            return result;
        }

        private String getPostDataString(HashMap<String, String> params)
                throws UnsupportedEncodingException {
            StringBuilder result = new StringBuilder();

            boolean first = true;

            for(Map.Entry<String, String> entry : params.entrySet()){
                if (first)
                    first = false;
                else
                    result.append("&");

                result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
                result.append("=");
                result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
            }

            return result.toString();
        }

        @Override
        protected void onPostExecute(String result) {

            StringTokenizer st = new StringTokenizer(result,";");
            List<String> list = new ArrayList<String>();

            System.out.println(result);

            while(st.hasMoreTokens()) {
                String tmp = st.nextToken();
                list.add(tmp);
                System.out.println(tmp);
            }

            for (int i=0;i<list.size();i++) {
                PREGUNTAS.get(i).setRespuestas(list.get(i));
            }

            int [] aleatorios = new Barajear().barajea(list.size());

            for (int i=0;i<list.size();i++)
                PREGUNTAS_SELECCIONADAS.add(PREGUNTAS.get(aleatorios[i]));

            for (int i=0;i<list.size();i++)
                System.out.println("correcto " + PREGUNTAS_SELECCIONADAS.get(i).getEl_bueno());

            ((ImageButton) findViewById(R.id.QuizButton)).setEnabled(true);
            ((ImageButton) findViewById(R.id.ConsultaButton)).setEnabled(true);
        }
    }
}
