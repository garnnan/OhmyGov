package com.example.ricardo.politicos;

import java.util.ArrayList;

/**
 * Created by Ricardo on 16/04/2016.
 */
public class Pregunta {

    private final String pregunta;
    private ArrayList<String> respuestas;
    private String el_bueno;

    public Pregunta(String pregunta)
    {
        this.pregunta = pregunta;
    }

    public void setRespuestas(String respuestas) {

        ArrayList<String> tmp = new ArrayList<String>();

        String [] tm_res = respuestas.split(",");

        for (int i=0;i<tm_res.length;i++)
            tmp.add(tm_res[i]);

        el_bueno = tmp.get(0);

        this.respuestas = new ArrayList<>();

        int [] numeros = new Barajear().barajea(tmp.size());

        for(int i=0;i<numeros.length;i++)
            this.respuestas.add(tmp.get(numeros[i]));

    }

    public ArrayList<String> getRespuestas() {
        return respuestas;
    }

    public String getEl_bueno()
    {
        return el_bueno;
    }

    public void setEl_bueno(String el_bueno)
    {
        this.el_bueno = el_bueno;
    }

    public String getPregunta() {
        return pregunta;
    }

    @Override
    public String toString() {
        String st = pregunta+";";
        st+=el_bueno+";";
        for(int i=0;i<respuestas.size();i++)
        {
            st+=respuestas.get(i);
            if(i<respuestas.size()-1)
                st+=",";
            else
                st+=";";
        }
        return st;
    }
}
