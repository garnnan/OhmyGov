package com.example.ricardo.politicos;

import android.content.Intent;
import android.content.pm.ActivityInfo;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

public class MainActivity extends AppCompatActivity  {

    private final static Spinner [] DATOS = new Spinner[3];
    private Button entrar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_PORTRAIT);

        int [] numeros = new Barajear().barajea(10);

        for (int n :
                numeros) {
            System.out.println(n);
        }

        DATOS [0] = (Spinner) findViewById(R.id.EstadoSpinner);
        DATOS [1] = (Spinner) findViewById(R.id.MunicipioSpinner);
        DATOS [2] = (Spinner) findViewById(R.id.DistritoSpinner);

        entrar = (Button) findViewById(R.id.IngresarButton);

        new llamada_spinner().execute("","","http://armenianwesterproject.hol.es/estados.php");

        DATOS[0].setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        int tmp = position + 1;
                        new llamada_spinner().execute("estado",
                                Integer.toString(tmp),
                                "http://armenianwesterproject.hol.es/municipios.php");
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                }
        );

        DATOS[1].setOnItemSelectedListener(
                new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int position, long id) {
                        int tmp = position + 1;
                        new llamada_spinner().execute("municipio",
                                Integer.toString(tmp),
                                "http://armenianwesterproject.hol.es/distritos.php");
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> parent) {

                    }
                }
        );

    }

    public void entrar(View v)
    {
        Intent i = new Intent(this,Eleccion.class);
        i.putExtra("estado",DATOS[0].getSelectedItem().toString());
        i.putExtra("municipio",DATOS[1].getSelectedItem().toString());
        i.putExtra("distrito",DATOS[2].getSelectedItem().toString());
        startActivity(i);
    }

    private class llamada_spinner extends AsyncTask<String,Void,String>
    {

        private String campo;

        @Override
        protected String doInBackground(String... params) {
            String resultado = "";

            try {
                campo = params[0];
                String info = params[1];
                URL url = new URL(params[2]);

                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(15000);
                conn.setConnectTimeout(15000);
                conn.setRequestMethod("POST");
                conn.setDoInput(true);
                conn.setDoOutput(true);

                HashMap<String,String> postDataParams = new HashMap<>();

                postDataParams.put(campo,info);

                OutputStream os = conn.getOutputStream();

                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os,"UTF-8"));

                writer.write(getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = conn.getResponseCode();

                if(responseCode == HttpURLConnection.HTTP_OK)
                {
                    String line;
                    BufferedReader br = new BufferedReader
                            (new InputStreamReader(conn.getInputStream()));
                    while ((line=br.readLine())!=null)
                        resultado += line;
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
            return  resultado;
        }

        private String getPostDataString(HashMap<String, String> params)
                throws UnsupportedEncodingException {
            StringBuilder result = new StringBuilder();

            boolean first = true;

            for(Map.Entry<String, String> entry : params.entrySet()){
                if (first)
                    first = false;
                else
                    result.append("&");

                result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
                result.append("=");
                result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
            }

            return result.toString();
        }

        @Override
        protected void onPostExecute(String resultado) {

            StringTokenizer st = new StringTokenizer(resultado,";");
            List<String> list = new ArrayList<String>();

            System.out.println(resultado);

            while(st.hasMoreTokens())
                list.add(st.nextToken());

            Spinner sp;

            switch (campo)
            {
                case "" :
                    sp = DATOS[0];
                    break;
                case "estado" :
                    sp = DATOS[1];
                    break;
                case "municipio":
                    sp = DATOS[2];
                    break;
                default:
                    sp = null;
            }

            ArrayAdapter<String> adapter = new ArrayAdapter<String>(getApplicationContext(),
                    android.R.layout.simple_spinner_dropdown_item,list);

            sp.setAdapter(adapter);
        }
    }
}
