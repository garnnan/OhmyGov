package com.example.ricardo.politicos;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.widget.GridLayout;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

public class ConsultaCandidatos extends AppCompatActivity {

    private GridLayout gridView;
    private ArrayList<LinearLayout> data_layout;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consulta_candidatos);



        gridView  = (GridLayout) findViewById(R.id.subgrid);

        gridView.removeAllViews();

        for (int i=0;i<10;i++)
        {

            data_layout = new ArrayList<>();
            data_layout.add(new LinearLayout(getApplicationContext()));

            ImageView image = new ImageView(getApplicationContext());
            image.setLayoutParams(new LinearLayout.LayoutParams(280, 280));
            //image.setImageDrawable((getResources()).getDrawable(R.drawable.volva));

            TextView text_actual = new TextView(getApplicationContext());
            text_actual.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 18);
            text_actual.setTextColor(0xffffffff);
            text_actual.setText("actual");

            data_layout.get(0).addView(image);
            data_layout.get(0).addView(text_actual);
            data_layout.get(0).setOrientation(LinearLayout.VERTICAL);

            data_layout.get(0).setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    Intent i = new Intent(ConsultaCandidatos.this, WebAccess.class);
                    startActivity(i);
                }
            });

            gridView.addView(data_layout.get(0), 550, 550);
        }
    }


}
