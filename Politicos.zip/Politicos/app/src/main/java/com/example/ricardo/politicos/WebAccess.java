package com.example.ricardo.politicos;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebView;

public class WebAccess extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_web_access);
        //https://www.google.com.mx/webhp?hl=es-419

        WebView w = (WebView) findViewById(R.id.webView);

        w.loadUrl("https://www.google.com.mx/webhp?hl=es-419");

    }
}
