package com.example.ricardo.politicos;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.AsyncTask;
import android.provider.Telephony;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.TypedValue;
import android.view.View;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.StringTokenizer;

public class Consulta extends AppCompatActivity {

    private GridLayout gridView;
    private ArrayList<LinearLayout> data_layout;

    private static final ArrayList<String[]> listas = new ArrayList<>();

    private Bitmap liga(String src)
    {
        try {

            URL url = new URL(src);

            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setDoInput(true);
            conn.connect();

            InputStream inputStream = conn.getInputStream();
            Bitmap bitmap = BitmapFactory.decodeStream(inputStream);

            return bitmap;

        }catch (Exception e){
            return null;
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_consultas);

        gridView  = (GridLayout) findViewById(R.id.consultasGrid);

        gridView.removeAllViews();

        Intent ia = getIntent();

        new preguntar().execute(ia.getStringExtra("estado"), ia.getStringExtra("municipio"), ia.getStringExtra("distrito"), "http://armenianwesterproject.hol.es/muestraData.php");

        int par = 0;



        for (int i=0;i<10;i++)
        {
            data_layout = new ArrayList<>();
            data_layout.add(new LinearLayout(getApplicationContext()));

            ImageView image = new ImageView(getApplicationContext());
            image.setLayoutParams(new LinearLayout.LayoutParams(280, 280));
            //image.setImageDrawable((getResources()).getDrawable(R.drawable.volva));
            //Bitmap bitmap = liga("http://moment-of-peace.com/images/books.png");





            TextView text_actual = new TextView(getApplicationContext());
            text_actual.setTextSize(TypedValue.COMPLEX_UNIT_DIP, 18);
            text_actual.setTextColor(0xffffffff);
            text_actual.setText("actual");

            data_layout.get(0).addView(image);
            data_layout.get(0).addView(text_actual);
            data_layout.get(0).setOrientation(LinearLayout.VERTICAL);

            data_layout.get(0).setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    Intent i = new Intent(Consulta.this, WebAccess.class);
                    startActivity(i);
                }
            });


            data_layout.get(0).setBackgroundColor(0x828282);

            data_layout.add(new LinearLayout(getApplicationContext()));

            TextView candidatos [] = new TextView[3];

            data_layout.get(1).setOrientation(LinearLayout.VERTICAL);

            data_layout.get(1).setBackgroundColor(0x050505);

            data_layout.get(1).setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    Intent i = new Intent(Consulta.this, ConsultaCandidatos.class);
                    startActivity(i);
                }
            });

            for (int j=0;j<candidatos.length;j++)
            {
                candidatos[j] = new TextView(getApplicationContext());
                candidatos[j].setTextSize(TypedValue.COMPLEX_UNIT_DIP, 18);
                candidatos[j].setTextColor(0xffffffff);
                candidatos[j].setText("candidato\n");
                data_layout.get(1).addView(candidatos[j]);
            }

            gridView.addView(data_layout.get(0),550,550);
            gridView.addView(data_layout.get(1),500,500);

        }

    }

    private class preguntar extends AsyncTask<String,Void,String>
    {

        @Override
        protected String doInBackground(String... params) {
            String result = "";
            try {

                URL url = new URL(params[3]);

                HttpURLConnection conn = (HttpURLConnection) url.openConnection();
                conn.setReadTimeout(15000);
                conn.setConnectTimeout(15000);
                conn.setRequestMethod("POST");
                conn.setDoInput(true);
                conn.setDoOutput(true);

                HashMap<String,String> postDataParams = new HashMap<>();

                postDataParams.put("municipio",params[0]);
                postDataParams.put("estado",params[1]);
                postDataParams.put("distrito",params[2]);


                OutputStream os = conn.getOutputStream();

                BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os,"UTF-8"));

                writer.write(getPostDataString(postDataParams));

                writer.flush();
                writer.close();
                os.close();

                int responseCode = conn.getResponseCode();

                if(responseCode == HttpURLConnection.HTTP_OK)
                {
                    String line;
                    BufferedReader br = new BufferedReader
                            (new InputStreamReader(conn.getInputStream()));
                    while ((line=br.readLine())!=null)
                        result += line;
                }

            } catch (Exception e) {
                e.printStackTrace();
            }
            return result;
        }

        private String getPostDataString(HashMap<String, String> params)
                throws UnsupportedEncodingException {
            StringBuilder result = new StringBuilder();

            boolean first = true;

            for(Map.Entry<String, String> entry : params.entrySet()){
                if (first)
                    first = false;
                else
                    result.append("&");

                result.append(URLEncoder.encode(entry.getKey(), "UTF-8"));
                result.append("=");
                result.append(URLEncoder.encode(entry.getValue(), "UTF-8"));
            }

            return result.toString();
        }

        @Override
        protected void onPostExecute(String result) {

            StringTokenizer st = new StringTokenizer(result,";");
            List<String> list = new ArrayList<String>();

            System.out.println(result);

            while(st.hasMoreTokens()) {
                String tmp = st.nextToken();
                list.add(tmp);
                System.out.println(tmp);
            }

            for (int i=0;i<list.size();i++)
            {
                listas.add(list.get(i).split(","));
            }
        }
    }

}
