package com.example.ricardo.politicos;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.widget.TextView;

public class Score extends AppCompatActivity {

    private static int score;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_score);

        score = getIntent().getIntExtra("score",0);

        ((TextView)findViewById(R.id.scoreView)).setText("tu score fue de\n"+score+"/5");

    }
}
