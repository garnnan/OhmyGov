package com.example.ricardo.politicos;

import java.util.ArrayList;
import java.util.Random;

/**
 * Created by Ricardo on 16/04/2016.
 */
public class Barajear {

    public int [] barajea(int tam)
    {
        int [] numeros = new int[tam];

        for (int i=0;i<tam;i++) {
            int temp = new Random().nextInt(tam);
            int j=0;
            while(j<i){
                if(temp == numeros[j]) {
                    temp = new Random().nextInt(tam);
                    j=0;
                }
                else
                    j++;
            }
            numeros[i] = temp;
        }
        return numeros;
    }

}
