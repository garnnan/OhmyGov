package com.example.ricardo.politicos;

import android.content.Intent;
import android.os.AsyncTask;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.TextView;
import android.widget.Toast;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.io.UnsupportedEncodingException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Quiz extends AppCompatActivity {

    private final static CheckBox [] RESPUESTAS = new CheckBox[4];
    private TextView pregunta;
    private int index,score;
    private String corregir;

    private ArrayList<Pregunta> preguntas = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_quiz);

        RESPUESTAS [0] = (CheckBox) findViewById(R.id.checkBox1);
        RESPUESTAS [1] = (CheckBox) findViewById(R.id.checkBox2);
        RESPUESTAS [2] = (CheckBox) findViewById(R.id.checkBox3);
        RESPUESTAS [3] = (CheckBox) findViewById(R.id.checkBox4);

        pregunta = (TextView) findViewById(R.id.preguntaView);

        index = getIntent().getIntExtra("index",0);
        score = getIntent().getIntExtra("score", 0);

        try {

            System.out.println(score);

            corregir = getIntent().getStringExtra("correccion");

            meter_datos("pregunta1", 0);
            meter_datos("pregunta2", 1);
            meter_datos("pregunta3", 2);
            meter_datos("pregunta4", 3);
            meter_datos("pregunta5", 4);

            for (int j=0;j<preguntas.size();j++)
                System.out.print(preguntas.get(j)+" ");
            System.out.println();

            Pregunta p = preguntas.get(index);

            pregunta.setText(p.getPregunta());

            for (int i = 0; i < p.getRespuestas().size(); i++) {
                RESPUESTAS[i].setText(p.getRespuestas().get(i));

                final int finalI = i;
                RESPUESTAS[i].setOnClickListener(new View.OnClickListener() {

                    @Override
                    public void onClick(View v) {

                        String respueta;

                        if (RESPUESTAS[finalI].getText().toString().equalsIgnoreCase(preguntas.get(index).getEl_bueno())) {
                            ++score;
                            respueta = "Correcta";
                        } else {
                            respueta = "Incorrecta";
                            corregir += index + ";";
                        }

                        Toast.makeText(getApplicationContext(), "la respuesta es " + respueta, Toast.LENGTH_LONG);
                        Intent i = new Intent(Quiz.this, Quiz.class);
                        i.putExtra("score", score);
                        i.putExtra("index", ++index);
                        i.putExtra("correccion", corregir);
                        i.putExtra("pregunta1", preguntas.get(0).toString());
                        i.putExtra("pregunta2", preguntas.get(1).toString());
                        i.putExtra("pregunta3", preguntas.get(2).toString());
                        i.putExtra("pregunta4", preguntas.get(3).toString());
                        i.putExtra("pregunta5", preguntas.get(4).toString());

                        startActivity(i);
                        finish();

                    }
                });
            }
        }catch (Exception e){

            Intent i = new Intent(this,Score.class);
            i.putExtra("score",score);
            startActivity(i);
            finish();
        }

    }

    private void meter_datos(String pregunta,int i)
    {
        String n1 = getIntent().getStringExtra(pregunta);
        String ns1 [] = n1.split(";");
        preguntas.add(new Pregunta(ns1[0]));
        preguntas.get(i).setEl_bueno(ns1[1]);
        preguntas.get(i).setRespuestas(ns1[2]);
    }

}
